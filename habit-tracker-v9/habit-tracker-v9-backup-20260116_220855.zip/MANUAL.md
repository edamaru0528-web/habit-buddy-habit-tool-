# 習慣化トラッカー Ver 9.0 使用マニュアル

## 📖 目次

1. [システム概要](#システム概要)
2. [アーキテクチャ](#アーキテクチャ)
3. [管理画面の使い方](#管理画面の使い方)
4. [子ページ（生徒用）の使い方](#子ページ生徒用の使い方)
5. [データ構造](#データ構造)
6. [計算式・ロジック](#計算式ロジック)
7. [一時停止機能の仕様](#一時停止機能の仕様)
8. [クラウド同期の仕組み](#クラウド同期の仕組み)
9. [トラブルシューティング](#トラブルシューティング)

---

## システム概要

習慣化トラッカーは、コーチが複数の生徒の習慣を管理し、生徒が日々の習慣をトラッキングするためのWebアプリケーションです。

### 主な機能
- **管理画面（admin.html）**: コーチが生徒を追加・管理し、各生徒の進捗状況をリアルタイムで確認
- **子ページ（index.html）**: 生徒が自分の習慣を記録・追跡

### 技術スタック
- HTML/CSS/JavaScript（フレームワーク不使用）
- クラウドストレージ: JSONBin.io
- ホスティング: Vercel
- PWA対応（Service Worker）

---

## アーキテクチャ

```
┌─────────────────────────────────────────────────────────────┐
│                      JSONBin.io (クラウド)                    │
├─────────────────────────────────────────────────────────────┤
│  マスターBin (69678ac9d0ea881f406b5bc5)                      │
│  ├── users: [ユーザーリスト + 各ユーザーのbinId]               │
│  └── baseUrl: 公開URL設定                                    │
│                                                             │
│  ユーザー個別Bin (各ユーザーごとに自動作成)                     │
│  ├── habits: [習慣リスト]                                    │
│  └── logs: [記録ログリスト]                                   │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│   管理画面       │ │   子ページA      │ │   子ページB      │
│  (admin.html)   │ │ (index.html     │ │ (index.html     │
│                 │ │  ?user=xxx)     │ │  ?user=yyy)     │
│  コーチPC/       │ │                 │ │                 │
│  スマホ          │ │  生徒Aの端末     │ │  生徒Bの端末     │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

---

## 管理画面の使い方

### アクセス方法
```
https://[your-domain]/admin.html
```

### 主な機能

#### 1. 公開URL設定
管理画面上部の「公開URL設定」に、Vercelの公開URLを入力して「設定保存」を押す。
- 例: `https://habit-buddy-habit-tool.vercel.app/`
- この設定はクラウドに保存され、全てのデバイスで共有される

#### 2. ユーザー（生徒）の追加
1. 「学習者名...」入力欄に名前を入力
2. 「作成」ボタンをクリック
3. 一意のIDが自動生成され、専用URLが発行される

#### 3. ユーザー一覧の確認
各ユーザーカードには以下が表示される：
- **ユーザー名**
- **経過日数**: 習慣開始からの日数
- **継続日数**: 連続で活動があった日数
- **達成率**: 本日の目標達成率（プログレスリング）

#### 4. ユーザーの操作（⋮メニュー）
- **リンク**: 生徒用ページのURLを表示
- **QRコード**: 生徒用ページのQRコードを表示
- **遠隔編集**: 習慣の追加・編集（コーチが代理で編集可能）
- **削除**: ユーザーを削除

#### 5. 全て同期
「🔄 全て同期（クラウドから取得）」ボタンを押すと：
1. ローカルにあるデータをクラウドにプッシュ
2. クラウドから最新データを取得
3. 画面を更新

### バックアップ機能
- **JSONで全保存**: 全ユーザーのデータをJSONファイルでダウンロード
- **JSONから復元**: JSONファイルからデータを復元
- **全ユーザーCSV**: 全ユーザーの進捗をCSVでダウンロード

---

## 子ページ（生徒用）の使い方

### アクセス方法
```
https://[your-domain]/index.html?user=[userId]
```

### ホーム画面

#### 進行状況リング
- 中央の円形グラフで本日の全体進捗を表示
- 各習慣が色分けされたセグメントで表示

#### 習慣カード
各習慣カードには以下が表示される：
- **習慣名**
- **🔥継続日数**（連続活動日数）
- **現在値/目標値**
- **達成率**

#### 記録方法

##### 回数/分タイプの習慣
- 数値入力欄に直接値を入力
- 値を変更するとクラウドに自動同期

##### チェックタイプの習慣
- ✓ボタンをタップでON/OFF切り替え
- ONにすると値が1になる

### 習慣の追加

#### クイック追加
1. 習慣名を入力
2. タイプを選択（回数/分/チェック）
3. 目標値を設定
4. 「追加」ボタン

#### モーダルから追加
1. 右下の「＋」ボタンをタップ
2. 習慣名、タイプ、カテゴリー、目標を入力
3. 「追加」ボタン

### 習慣の編集
1. 習慣カードをタップ
2. 編集モーダルで以下を変更可能：
   - 項目名
   - タイプ
   - 目標値
   - カテゴリー
   - 色
   - 開始日
   - **一時停止の設定**

### 今日の振り返り
ホーム画面下部のテキスト欄に振り返りを入力すると自動保存される。

### 画面タブ
- **ホーム**: 今日の習慣一覧
- **履歴**: 過去の記録をフォルダ形式で閲覧
- **月間**: カレンダービューで月間の達成状況を確認
- **分析**: 曜日別・項目別の達成率グラフ

---

## データ構造

### マスタービン（ユーザーリスト）

```json
{
  "users": [
    {
      "id": "abc123",           // 一意のユーザーID（自動生成）
      "name": "山田太郎",        // ユーザー名
      "startDate": "2026-01-01", // 登録日
      "binId": "xyz789"         // 個別データ保存先のBin ID
    }
  ],
  "baseUrl": "https://example.vercel.app/"
}
```

### ユーザー個別データ

```json
{
  "habits": [
    {
      "id": "habit123",          // 習慣の一意ID
      "name": "朝の読書",         // 習慣名
      "type": "minutes",         // タイプ: "count" | "minutes" | "check"
      "goal": 30,                // 現在の目標値
      "category": "学習",        // カテゴリー
      "color": "#00B4B4",        // 表示色（16進数）
      "startDate": "2026-01-01", // 開始日
      "isPaused": false,         // 一時停止中かどうか
      "pausedDate": null,        // 一時停止した日付（停止中のみ）
      "goalHistory": [           // 目標変更履歴
        { "date": "2026-01-01", "value": 20 },
        { "date": "2026-01-10", "value": 30 }
      ]
    }
  ],
  "logs": [
    {
      "habit": "朝の読書",         // 習慣名（習慣名で紐付け）
      "value": 25,               // 記録した値
      "timestamp": "2026-01-15T08:30:00.000Z" // 記録日時（ISO形式）
    }
  ],
  "reflections": {
    "2026-01-15": "今日は集中できた！"
  },
  "lastConfettiDate": "2026-01-15"  // 最後に紙吹雪を表示した日
}
```

---

## 計算式・ロジック

### 1. 達成率（1日）

```javascript
function getDailyProgress(data, dateKey) {
    // アクティブな習慣のみ対象
    const activeHabits = data.habits.filter(h => {
        if (h.startDate > dateKey) return false;  // まだ開始していない
        if (h.isPaused && h.pausedDate && h.pausedDate <= dateKey) return false;  // 停止日以降
        return true;
    });
    
    if (activeHabits.length === 0) return 0;
    
    // 各習慣の達成率を合計
    const totalPct = activeHabits.reduce((sum, h) => {
        const status = getHabitStatusAtDate(h, data.logs, dateKey);
        return sum + status.pct;  // pct = min(1, current / goal)
    }, 0);
    
    // 平均を%で返す
    return Math.floor((totalPct / activeHabits.length) * 100);
}
```

**計算式:**
```
達成率(%) = Σ(各習慣の min(現在値/目標値, 1)) / アクティブ習慣数 × 100
```

### 2. 習慣ごとの達成状況

```javascript
function getHabitStatusAtDate(habit, logs, dateKey) {
    // その日のログを抽出
    const dayLogs = logs.filter(l => 
        l.habit === habit.name && 
        l.timestamp.split('T')[0] === dateKey
    );
    
    // 現在値 = ログの値の合計
    const current = dayLogs.reduce((sum, l) => sum + (l.value || 1), 0);
    
    // その日の目標値を取得（履歴から）
    const goal = getGoalAtDate(habit, dateKey);
    
    return {
        current,                           // 現在値
        goal,                              // 目標値
        isAchieved: current >= goal,       // 達成したか
        hasActivity: current >= 1,         // 1以上の活動があったか
        pct: Math.min(1, current / goal)   // 達成率（0〜1）
    };
}
```

### 3. 継続日数（ストリーク）

```javascript
function calculateStreak(habit, logs) {
    let streak = 0;
    let checkDate = new Date();
    const todayKey = getDateKey(checkDate);
    const todayStatus = getHabitStatusAtDate(habit, logs, todayKey);

    // 今日活動がなければ昨日から開始
    if (!todayStatus.hasActivity) {
        checkDate.setDate(checkDate.getDate() - 1);
    }

    // 過去に遡って連続活動日を数える
    while (true) {
        const key = getDateKey(checkDate);
        if (key < habit.startDate) break;  // 開始日より前は無視
        
        const status = getHabitStatusAtDate(habit, logs, key);
        if (status.hasActivity) {  // 1以上の活動があればカウント
            streak++;
            checkDate.setDate(checkDate.getDate() - 1);
        } else {
            break;  // 活動がなければ終了
        }
    }
    return streak;
}
```

**ストリークのルール:**
- 活動判定: `current >= 1`（目標達成ではなく、1以上の記録があればOK）
- 今日記録がなくても、昨日までの連続は維持される
- 開始日より前は計算対象外

### 4. 目標値の履歴対応

```javascript
function getGoalAtDate(habit, dateKey) {
    const history = [...habit.goalHistory].sort((a, b) => 
        new Date(a.date) - new Date(b.date)
    );
    
    // dateKey以前で最も新しい目標を探す
    let activeGoal = history[0].value;
    for (const entry of history) {
        if (entry.date <= dateKey) {
            activeGoal = entry.value;
        } else {
            break;
        }
    }
    return activeGoal;
}
```

**例:**
- 1/1: 目標20に設定
- 1/10: 目標30に変更
- 1/5時点の達成率計算 → 目標20で計算
- 1/15時点の達成率計算 → 目標30で計算

### 5. 継続日数の色分け

```javascript
function getStreakColor(streak) {
    if (streak <= 3) return '#fcd34d';   // 薄いオレンジ/イエロー
    if (streak <= 7) return '#f59e0b';   // オレンジ
    if (streak <= 14) return '#ea580c';  // 濃いオレンジ
    if (streak <= 30) return '#dc2626';  // レッドオレンジ
    return '#b91c1c';                    // 深い赤
}
```

---

## 一時停止機能の仕様

### 概要
習慣を一時的に記録対象から外す機能。旅行中や体調不良時などに使用。

### データ構造

```json
{
    "isPaused": true,           // 停止中フラグ
    "pausedDate": "2026-01-15"  // 停止した日付
}
```

### 停止時の処理

```javascript
// 停止する場合
habit.isPaused = true;
habit.pausedDate = getDateKey();  // 今日の日付を記録
```

### 再開時の処理

```javascript
// 再開する場合
habit.isPaused = false;
delete habit.pausedDate;  // 停止日を削除
```

### 達成率計算への影響

```javascript
const activeHabits = data.habits.filter(h => {
    if (h.startDate > dateKey) return false;  // 未開始
    if (h.isPaused && h.pausedDate && h.pausedDate <= dateKey) return false;  // 停止日以降は除外
    return true;
});
```

**ルール:**
- `isPaused = true` かつ `pausedDate <= 対象日` → 計算対象外
- 停止日より前の記録は達成率に含まれる
- 再開後は通常通り計算対象

### UI表示
- 停止中の習慣はグレーアウト表示
- 「記録停止中」と表示
- 「再開」ボタンでワンタップ再開可能

---

## クラウド同期の仕組み

### JSONBin.io API設定

```javascript
const JSONBIN_MASTER_KEY = '$2a$10$9gCdL3y87QxebgxH9Ea1eOT93VPPLvVcj/czCK0PaWCL3WLhOutcC';
const JSONBIN_API = 'https://api.jsonbin.io/v3/b';
const USERS_BIN_ID = '69678ac9d0ea881f406b5bc5';  // マスターユーザーリスト
```

### 同期フロー（管理画面）

```
1. ページ読み込み
    │
    ▼
2. fetchAllDataFromCloud()
    ├── マスターリスト取得
    ├── ユーザーリストをlocalStorageに保存
    └── 各ユーザーのbinIdをlocalStorageに保存
    │
    ▼
3. repairMissingBinIds()
    └── binIdがないユーザーには新規Bin作成
    │
    ▼
4. pushAllLocalDataToCloud()
    └── ローカルにあるデータをクラウドにプッシュ
    │
    ▼
5. fetchAllUsersDataFromCloud()
    └── 全ユーザーの最新データをクラウドから取得
    │
    ▼
6. renderUsers()
    └── 画面に表示
```

### 同期フロー（子ページ）

```
1. ページ読み込み
    │
    ▼
2. setupUI()
    ├── マスターリストからユーザー情報取得
    └── binIdをlocalStorageに保存
    │
    ▼
3. fetchFromCloud()
    └── そのユーザーのデータをクラウドから取得
    │
    ▼
4. renderHabits()
    └── 画面に表示

--- 記録時 ---

5. saveData(data)
    ├── localStorageに保存
    └── syncToCloud(data)
        └── クラウドにプッシュ
```

### localStorage キー一覧

| キー | 内容 |
|------|------|
| `habitTracker_users` | ユーザーリスト |
| `habitTracker_baseUrl` | 公開URL設定 |
| `habitTracker_binId_{userId}` | 各ユーザーのBin ID |
| `habitTracker_{userId}` | 各ユーザーの習慣・ログデータ |

---

## トラブルシューティング

### 問題: データが同期されない
**原因**: binIdがマスターリストに登録されていない
**解決**: 管理画面を開くと自動的に修復される

### 問題: 別のデバイスでデータが表示されない
**原因**: 元のデバイスでクラウドに同期されていない
**解決**: 
1. 元のデバイスで管理画面を開く
2. 「全て同期」ボタンを押す

### 問題: ユーザーが0%と表示される
**原因**: そのユーザーのbinIdがlocalStorageに保存されていない
**解決**: ページをリロードすると自動的にマスターリストからbinIdを取得

### 問題: LINEから「ブラウザで開く」でデータが消える
**原因**: 以前はbinIdがデバイス間で共有されていなかった
**解決**: 現在のバージョンでは修正済み。マスターリストからbinIdを取得するため、どのデバイスでも同じデータにアクセス可能

### コンソールログで確認すべきメッセージ

| メッセージ | 意味 |
|-----------|------|
| `All data fetched from cloud` | マスターリスト取得成功 |
| `All users data fetched from cloud` | 全ユーザーデータ取得成功 |
| `Got Bin ID from master: xxx` | マスターリストからbinId取得成功 |
| `Data synced to cloud` | クラウドへのプッシュ成功 |
| `Auto-pushing local data to cloud: ユーザー名` | ローカルデータの自動プッシュ |

---

## 更新履歴

- **Ver 9.0**: クロスブラウザ同期機能実装（binIdのマスターリスト管理）
- **Ver 8.0**: 目標履歴機能、一時停止機能追加
- **Ver 7.0**: JSONBin.ioへのクラウド移行
